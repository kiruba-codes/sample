# junit-bank-example

Simple JUnit 4 example

An example of Chapter _Junit_ of the book

[Test-Driven Development, Build Automation, Continuous Integration (with Java, Eclipse and friends)](https://leanpub.com/tdd-buildautomation-ci)
by _Lorenzo Bettini_.

See https://github.com/LorenzoBettini/tdd-buildautomation-ci-book-examples for the list of all the examples.
